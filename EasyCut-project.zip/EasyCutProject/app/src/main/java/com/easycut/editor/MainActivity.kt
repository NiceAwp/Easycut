package com.easycut.editor

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast
import android.widget.MediaController

class MainActivity : Activity() {
    private lateinit var videoView: VideoView
    private lateinit var status: TextView
    private val pickVideoCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 17, 25)
        window.navigationBarColor = Color.rgb(15, 17, 25)
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 18)
            setBackgroundColor(Color.rgb(15, 17, 25))
        }

        val title = TextView(this).apply {
            text = "EasyCut"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 56))

        val subtitle = TextView(this).apply {
            text = "Простой монтаж без лишних меню"
            textSize = 15f
            setTextColor(Color.rgb(180, 186, 204))
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 36))

        videoView = VideoView(this).apply {
            setBackgroundColor(Color.rgb(30, 33, 45))
        }
        root.addView(videoView, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = 12
            bottomMargin = 14
        })

        val importButton = makeButton("＋  Выбрать видео")
        importButton.setOnClickListener { chooseVideo() }
        root.addView(importButton, buttonParams())

        val playButton = makeButton("▶  Воспроизвести / пауза")
        playButton.setOnClickListener {
            if (videoView.isPlaying) videoView.pause() else videoView.start()
        }
        root.addView(playButton, buttonParams())

        val trimButton = makeButton("✂  Обрезка — следующий этап")
        trimButton.setOnClickListener {
            Toast.makeText(this, "В первой сборке доступны импорт и просмотр. Экспорт обрезки добавим следующим этапом.", Toast.LENGTH_LONG).show()
        }
        root.addView(trimButton, buttonParams())

        status = TextView(this).apply {
            text = "Сначала выбери видео из галереи"
            textSize = 13f
            setTextColor(Color.rgb(180, 186, 204))
            gravity = Gravity.CENTER
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 44))

        setContentView(root)
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(91, 78, 235))
    }

    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, 56
    ).apply { bottomMargin = 10 }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickVideoCode)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoCode && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            videoView.setVideoURI(uri)
            videoView.setMediaController(MediaController(this))
            videoView.setOnPreparedListener {
                status.text = "Видео загружено • можно просматривать"
                it.isLooping = false
            }
            videoView.start()
        }
    }
}
